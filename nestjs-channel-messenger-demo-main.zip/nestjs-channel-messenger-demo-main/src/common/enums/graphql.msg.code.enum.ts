export enum GraphqlMsgCode {
  // channel
  CHANNEL_NOT_FOUND = 10001,

  // message
  MESSAGE_NOT_FOUND = 20001,
}
